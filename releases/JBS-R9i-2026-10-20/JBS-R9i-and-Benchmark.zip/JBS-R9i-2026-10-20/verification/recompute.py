from pathlib import Path
import argparse,hashlib,json,statistics,shutil,math
b=Path(__file__).resolve().parent
root=b.parent
p=argparse.ArgumentParser();p.add_argument('file',nargs='?',default='raw-game-record.anonymized.json');args=p.parse_args()
path=root/'data'/args.file
d=json.loads(path.read_text());assert d.get('ok') and d['stage']=='complete',d.get('error',d['stage'])
assert d['stopped'] and not any(d[k] for k in ['finalFastEnabled','finalNormalEnabled','finalAutoFarming'])
assert d['initialRebirths']==d['finalRebirths'] and not d['errors']
cals={x['label']:x for x in d['calibrations']};settles={x['label']:x for x in d['settles']}
rows=[]
for ph in d['phases']:
 assert ph['complete'] and 60<=ph['seconds']<60.5 and not ph.get('emergencyStop')
 assert all(s['toolEquipped'] for s in ph['samples'])
 assert ph['startRebirths']==ph['endRebirths']==d['initialRebirths']
 name=ph['name'];before=cals['before_'+name];after=cals['after_'+name]
 mean_unit=(before['gainPerSerialRequest']+after['gainPerSerialRequest'])/2
 assert abs(after['gainPerSerialRequest']/before['gainPerSerialRequest']-1)<.02
 start=float(ph['startStrength']);gain=float(ph['endStrength'])-start
 assert gain==ph['gain']
 points=[(0,start)]+[(s['seconds'],float(s['strength'])) for s in ph['samples']]+[(ph['seconds'],float(ph['endStrength']))]
 def at(t):
  for (t0,v0),(t1,v1) in zip(points,points[1:]):
   if t0<=t<=t1 and t1>t0:return (v0-start)+(v1-v0)*(t-t0)/(t1-t0)
  raise ValueError('uncovered time')
 ps=sorted(s['pingMs'] for s in ph['pingSamples'] if s.get('pingMs') is not None)
 assert len(ps)>=250
 def q(f):
  idx=(len(ps)-1)*f;lo=math.floor(idx);hi=math.ceil(idx)
  return ps[lo]+(ps[hi]-ps[lo])*(idx-lo)
 tail=settles['after_'+name];assert tail['stable']
 assert len({float(s['strength']) for s in tail['samples'][-3:]})==1
 tail_gain=float(tail['endStrength'])-float(ph['endStrength']);fullwall=tail['finishedClock']-ph['startedClock']
 row={'name':name,'mode':ph['mode'],'sourceLabel':d.get('candidateTag','R7 baseline') if ph['mode']=='r7' else 'Pastefy25',
  'seconds':ph['seconds'],'gain':gain,'strengthPerSecond':gain/ph['seconds'],
  'last30StrengthPerSecond':(at(60)-at(30))/30,'last15StrengthPerSecond':(at(60)-at(45))/15,
  'lowRateMeanBefore':before['gainPerSerialRequest'],'lowRateMeanAfter':after['gainPerSerialRequest'],'meanLowRateGain':mean_unit,
  'withinTrialUnitChangePercent':(after['gainPerSerialRequest']/before['gainPerSerialRequest']-1)*100,
  'pingMedianMs':statistics.median(ps),'pingP95Ms':q(.95),'pingMaxMs':max(ps),
  'fps':len(ph['frames'])/ph['seconds'],'heartbeatHz':ph['heartbeats']/ph['seconds'],
  'tailSeconds':tail['seconds'],'tailGain':tail_gain,'fullwallSeconds':fullwall,'strengthPerSecondIncludingTail':(gain+tail_gain)/fullwall,
  'drainingSamples':sum(s['draining'] for s in ph['samples']) if ph['mode']=='r7' else None,
  'localRequestsPerSecond':(ph['endFastSent']-ph['startFastSent'])/ph['seconds'] if ph['mode']=='r7' else ph['heartbeats']*25/ph['seconds']}
 for key in ['strengthPerSecond','last30StrengthPerSecond','last15StrengthPerSecond','strengthPerSecondIncludingTail']:
  row['lowRateGainNormalized_'+key]=row[key]/mean_unit
 rows.append(row)
result={'runId':d['runId'],'jobId':d['jobId'],'startedAt':d['startedAt'],'completedAt':d['completedAt'],'sourceSHA256':d['r7SourceSha256'],
 'referenceSHA256':d['pastefySourceSha256'],'showPopups':d.get('showPopups'),'rows':rows,'valid':True,
 'notes':['all rates based on actual observed Strength, not a per-call acknowledgement','counter subtraction uses original Luau binary64 semantics','one trial per script; no statistical superiority claim from a single pair']}
if len(rows)==2:
 a=next(x for x in rows if x['mode']=='r7');c=next(x for x in rows if x['mode']=='pastefy')
 assert abs(a['meanLowRateGain']/c['meanLowRateGain']-1)<.02
 result['comparison']={'rawSpeedPercent':(a['strengthPerSecond']/c['strengthPerSecond']-1)*100,
  'normalizedSpeedPercent':(a['lowRateGainNormalized_strengthPerSecond']/c['lowRateGainNormalized_strengthPerSecond']-1)*100,
  'normalizedLast30Percent':(a['lowRateGainNormalized_last30StrengthPerSecond']/c['lowRateGainNormalized_last30StrengthPerSecond']-1)*100,
  'normalizedLast15Percent':(a['lowRateGainNormalized_last15StrengthPerSecond']/c['lowRateGainNormalized_last15StrengthPerSecond']-1)*100,
  'pingMedianDifferenceMs':a['pingMedianMs']-c['pingMedianMs']}
out=root/'data'
(out/(path.stem+'-summary.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')

print(json.dumps(result,ensure_ascii=False,indent=2))
