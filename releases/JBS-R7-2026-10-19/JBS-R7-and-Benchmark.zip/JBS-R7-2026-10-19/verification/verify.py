"""A second calculation path: consume raw counters, not analyze.py helpers."""
from pathlib import Path
import json,math
b=Path(__file__).resolve().parent
out=b.parent/'data'
d=json.loads((out/'raw-game-record.anonymized.json').read_text())
s=json.loads((out/'summary.json').read_text())
checks=[]
def close(label,a,b):
 assert math.isclose(a,b,rel_tol=2e-12,abs_tol=1e-5),(label,a,b)
 checks.append(label)
cal={a['label']:a for a in d['calibrations']}
group={'r7':[],'pastefy':[]}
medians={'r7':[],'pastefy':[]}
for ph in d['phases']:
 row=next(x for x in s['rows'] if x['name']==ph['name'])
 seconds=ph['offRequestedClock']-ph['startedClock']
 gain=float(ph['endStrength'])-float(ph['startStrength'])
 value=gain/seconds
 close(ph['name']+' actual seconds',seconds,row['actualSeconds'])
 close(ph['name']+' rate',value,row['strengthPerSecond'])
 points=[(0,float(ph['startStrength']))]+[(x['seconds'],float(x['strength'])) for x in ph['samples']]
 # Independent path: integrate each interval's rate over its overlap with the
 # fixed 15..30 window instead of reusing cumulative-boundary interpolation.
 window_gain=0
 for left,right in zip(points,points[1:]):
  overlap=max(0,min(right[0],30)-max(left[0],15))
  if overlap:window_gain+=(right[1]-left[1])/(right[0]-left[0])*overlap
 close(ph['name']+' last15 rate',window_gain/15,row['last15StrengthPerSecond'])
 group[ph['mode']].append(value)
 ps=sorted(x['pingMs'] for x in ph['pingSamples'])
 n=len(ps);median=(ps[(n-1)//2]+ps[n//2])/2
 medians[ph['mode']].append(median)
 close(ph['name']+' median',median,row['pingMedianMs'])
 unit=(cal['before_'+ph['name']]['gain']/20+cal['after_'+ph['name']]['gain']/20)/2
 reference=d['calibrations'][0]['gain']/20
 close(ph['name']+' normalized',gain/seconds/unit*reference,row['normalizedStrengthPerSecond'])
 tail=next(x for x in d['settles'] if x['label']=='after_'+ph['name'])
 close(ph['name']+' tail rate',(float(tail['endStrength'])-float(ph['startStrength']))/(tail['finishedClock']-ph['startedClock']),row['strengthPerSecondIncludingTail'])
for mode in group:
 for key,values in [('strengthPerSecond',group[mode]),('pingMedianMs',medians[mode])]:
  mean=math.fsum(values)/5
  variance=math.fsum((v-mean)**2 for v in values)/4
  sd=math.sqrt(variance)
  close(mode+' '+key+' mean',mean,s['summary'][mode][key]['mean'])
  close(mode+' '+key+' sample SD',sd,s['summary'][mode][key]['sampleSD'])
  margin=2.7764451051977987*sd/math.sqrt(5)
  close(mode+' '+key+' lower CI',mean-margin,s['summary'][mode][key]['mean95CI'][0])
  close(mode+' '+key+' upper CI',mean+margin,s['summary'][mode][key]['mean95CI'][1])
ratios=[]
for pair in range(1,6):
 a=next(p for p in d['phases'] if p['pair']==pair and p['mode']=='r7')
 b=next(p for p in d['phases'] if p['pair']==pair and p['mode']=='pastefy')
 def normalized(p):
  unit=(cal['before_'+p['name']]['gain']+cal['after_'+p['name']]['gain'])/40
  return (float(p['endStrength'])-float(p['startStrength']))/(p['offRequestedClock']-p['startedClock'])/unit
 ratios.append(normalized(a)/normalized(b))
close('paired geometric ratio',math.prod(ratios)**.2,s['comparison']['pairedNormalizedGeometricRatio'])
receipt={'ok':True,'independentCalculationChecks':len(checks),'checks':checks,'rawRunId':d['runId'],
 'method':'second code path recalculates raw numerator, elapsed time, order-statistic median, sample variance and paired ratios; does not import analysis helpers'}
(out/'independent-verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'ok':True,'checks':len(checks)},ensure_ascii=False))
