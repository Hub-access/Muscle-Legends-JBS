from pathlib import Path
import datetime as dt,hashlib,json,math,statistics,shutil

base=Path(__file__).resolve().parent
root=base.parent
out=root/'data'
ws=out
raw=out/'raw-game-record.anonymized.json'
d=json.loads(raw.read_text())
# HttpService JSON may emit a large binary64 counter with an odd decimal final
# digit. Restore Luau's original number semantics before subtracting counters;
# Python's arbitrary-precision integer subtraction would invent a 1-unit delta.
def restore_counter_numbers(value):
 if isinstance(value,dict):
  for key,item in value.items():
   if key in {'strength','startStrength','endStrength'} and isinstance(item,(int,float)):
    value[key]=float(item)
   else:restore_counter_numbers(item)
 elif isinstance(value,list):
  for item in value:restore_counter_numbers(item)
restore_counter_numbers(d)
plan=json.loads((out/'plan.json').read_text())
assert d.get('ok') and d['stage']=='complete',d.get('error',d['stage'])
assert d['stopped'] and not any(d[k] for k in ['finalFastEnabled','finalNormalEnabled','finalAutoFarming'])
assert len(d['phases'])==10 and d['completedTrials']==10
assert d['pairOrder']==plan['pairs']
assert d['initialRebirths']==d['finalRebirths']
assert not d['errors'],d['errors']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'JBS-Fast-R7.lua')==d['r7SourceSha256']==plan['r7Sha256']
assert d['pastefySourceSha256']==plan['pastefySha256']  # Reference snapshot identified by hash, not redistributed.
assert sha(root/'JBS-Fast-R7.lua')==plan['r7Sha256']
settles={s['label']:s for s in d['settles']}
cals={s['label']:s for s in d['calibrations']}
assert len(cals)==20 and len(settles)==40
T4=2.7764451051977987
def stat(v):
 assert len(v)==5
 mean=statistics.mean(v);sd=statistics.stdev(v);margin=T4*sd/math.sqrt(5)
 return {'n':5,'mean':mean,'sampleSD':sd,'min':min(v),'max':max(v),'coefficientOfVariationPercent':sd/abs(mean)*100 if mean else None,'mean95CI':[mean-margin,mean+margin],'ciMethod':'Student t, df=4; conditional on trial independence'}
def quant(v,q):
 a=sorted(v);i=(len(a)-1)*q;lo=math.floor(i);hi=math.ceil(i)
 return a[lo]+(a[hi]-a[lo])*(i-lo)
def pet_identity(pets): return [(p['slot'],p['id'],p['name'],p['perks'].get('repTimeBoostPercent',0)) for p in pets]
identity=pet_identity(d['initialPets'])
rows=[]
reference=cals['before_'+d['phases'][0]['name']]['gainPerSerialRequest']
for ph in d['phases']:
 name=ph['name'];before=cals['before_'+name];after=cals['after_'+name];tail=settles['after_'+name]
 assert ph['complete'] and not ph.get('emergencyStop') and 30<=ph['seconds']<30.5
 assert ph['startRebirths']==ph['endRebirths']==d['initialRebirths']
 assert pet_identity(ph['petsBefore'])==pet_identity(ph['petsAfter'])==identity
 assert all(s['toolEquipped'] and s['rebirths']==d['initialRebirths'] for s in ph['samples'])
 assert all(sum((a-b)**2 for a,b in zip(s['position'],d['initialPosition']))<.25 for s in ph['samples'])
 assert tail['stable'] and len(tail['samples'])>=3
 assert len({s['strength'] for s in tail['samples'][-3:]})==1
 assert all(s['pingMs']<400 for s in tail['samples'][-3:])
 for cal in [before,after]:
  assert cal['requests']==20 and cal['gain']==cal['endStrength']-cal['startStrength']
  assert cal['gainPerSerialRequest']==cal['gain']/20
 assert abs(after['gainPerSerialRequest']/before['gainPerSerialRequest']-1)<.02
 assert ph['endStrength']-ph['startStrength']==ph['gain']
 # Interpolate the cumulative counter only at the fixed 15-second boundary.
 points=[(0,ph['startStrength'])]+[(s['seconds'],s['strength']) for s in ph['samples']]
 points.append((ph['seconds'],ph['endStrength']))
 assert all(b[1]>=a[1] for a,b in zip(points,points[1:]))
 def value_at(t):
  for (t0,v0),(t1,v1) in zip(points,points[1:]):
   # Center the very large absolute Strength counter before interpolation.
   # This preserves fractional boundary gains instead of rounding them at 2e16.
   if t0<=t<=t1 and t1>t0:return (v0-ph['startStrength'])+(v1-v0)*(t-t0)/(t1-t0)
  raise AssertionError(('Uncovered time',name,t))
 pings=[s['pingMs'] for s in ph['pingSamples'] if isinstance(s.get('pingMs'),(int,float))]
 assert len(pings)>=100
 unit=(before['gainPerSerialRequest']+after['gainPerSerialRequest'])/2
 fullwall=tail['finishedClock']-ph['startedClock']
 tailgain=tail['endStrength']-ph['endStrength']
 row={'pair':ph['pair'],'slot':ph['slot'],'ordinal':ph['ordinal'],'script':'JBS R7' if ph['mode']=='r7' else '第二脚本25档','mode':ph['mode'],'name':name,
 'actualSeconds':ph['seconds'],'strengthGain':ph['gain'],'strengthPerSecond':ph['gain']/ph['seconds'],
 'last15StrengthPerSecond':(value_at(30)-value_at(15))/15,
 'pingMedianMs':statistics.median(pings),'pingP95Ms':quant(pings,.95),'pingMaxMs':max(pings),'pingSampleCount':len(pings),
 'tailSeconds':tail['seconds'],'tailStrengthGain':tailgain,'fullwallSeconds':fullwall,
 'strengthPerSecondIncludingTail':(ph['gain']+tailgain)/fullwall,
 'maxPingIncludingTailMs':max(pings+[s['pingMs'] for s in tail['samples']]),
 'lowRateGainBefore':before['gainPerSerialRequest'],'lowRateGainAfter':after['gainPerSerialRequest'],'meanLowRateGain':unit,
 'withinTrialYieldChangePercent':(after['gainPerSerialRequest']/before['gainPerSerialRequest']-1)*100,
 'normalizedStrengthPerSecond':ph['gain']/ph['seconds']/unit*reference,
 'normalizedLast15StrengthPerSecond':(value_at(30)-value_at(15))/15/unit*reference,
 'fps':len(ph['frames'])/ph['seconds'],'heartbeatHz':ph['heartbeats']/ph['seconds'],
 'drainingSamples':sum(s['draining'] for s in ph['samples']) if ph['mode']=='r7' else None,
 'localRequestsPerSecond':(ph['endFastSent']-ph['startFastSent'])/ph['seconds'] if ph['mode']=='r7' else 25*ph['heartbeats']/ph['seconds'],
 'localRequestsMethod':'fast controller counter' if ph['mode']=='r7' else 'estimate: 25 times Heartbeat count; not server accepted count'}
 rows.append(row)
metrics=['strengthPerSecond','last15StrengthPerSecond','normalizedStrengthPerSecond','normalizedLast15StrengthPerSecond','pingMedianMs','pingP95Ms','tailSeconds','strengthPerSecondIncludingTail','localRequestsPerSecond','fps']
summary={mode:{key:stat([r[key] for r in rows if r['mode']==mode]) for key in metrics} for mode in ['r7','pastefy']}
pairs=[]
for i in range(1,6):
 a=next(r for r in rows if r['pair']==i and r['mode']=='r7');b=next(r for r in rows if r['pair']==i and r['mode']=='pastefy')
 yielddifference=(a['meanLowRateGain']/b['meanLowRateGain']-1)*100
 assert abs(yielddifference)<2
 pairs.append({'pair':i,'r7Ordinal':a['ordinal'],'pastefyOrdinal':b['ordinal'],'yieldDifferencePercent':yielddifference,
 'rawSpeedRatio':a['strengthPerSecond']/b['strengthPerSecond'],
 'normalizedSpeedRatio':a['normalizedStrengthPerSecond']/b['normalizedStrengthPerSecond'],
 'rawSpeedDifference':a['strengthPerSecond']-b['strengthPerSecond'],
 'normalizedSpeedDifference':a['normalizedStrengthPerSecond']-b['normalizedStrengthPerSecond'],
 'normalizedLast15Ratio':a['normalizedLast15StrengthPerSecond']/b['normalizedLast15StrengthPerSecond'],
 'pingMedianDifferenceMs':a['pingMedianMs']-b['pingMedianMs']})
logratios=[math.log(p['normalizedSpeedRatio']) for p in pairs]
logstat=stat(logratios)
comparison={'rawRatioOfMeans':summary['r7']['strengthPerSecond']['mean']/summary['pastefy']['strengthPerSecond']['mean'],
 'normalizedRatioOfMeans':summary['r7']['normalizedStrengthPerSecond']['mean']/summary['pastefy']['normalizedStrengthPerSecond']['mean'],
 'pairedNormalizedGeometricRatio':math.exp(logstat['mean']),
 'pairedNormalizedGeometricRatio95CI':[math.exp(x) for x in logstat['mean95CI']],
 'pairedRawDifference':stat([p['rawSpeedDifference'] for p in pairs]),
 'pairedNormalizedDifference':stat([p['normalizedSpeedDifference'] for p in pairs]),
 'pairedPingMedianDifferenceMs':stat([p['pingMedianDifferenceMs'] for p in pairs]),
 'last15RawRatioOfMeans':summary['r7']['last15StrengthPerSecond']['mean']/summary['pastefy']['last15StrengthPerSecond']['mean'],
 'last15NormalizedRatioOfMeans':summary['r7']['normalizedLast15StrengthPerSecond']['mean']/summary['pastefy']['normalizedLast15StrengthPerSecond']['mean']}
times=lambda s:dt.datetime.fromtimestamp(s,dt.timezone(dt.timedelta(hours=8))).isoformat()
result={'schema':1,'runId':d['runId'],'jobId':d['jobId'],'account':d['user'],'startBeijing':times(d['startedAt']),'endBeijing':times(d['completedAt']),
 'totalCampaignSeconds':d['finishedClock']-d['startedClock'],'r7Sha256':d['r7SourceSha256'],'pastefySha256':d['pastefySourceSha256'],
 'rows':rows,'summary':summary,'pairedComparisons':pairs,'comparison':comparison,
 'quality':{'completeTrials':10,'trialsPerScript':5,'calibrationCount':20,'originalScriptBytesUnchanged':True,'rebirthsUnchanged':True,
 'sameServerAccountCharacterPetsRepSpeedPositionWeight':True,'maxWithinTrialYieldChangePercent':max(abs(r['withinTrialYieldChangePercent']) for r in rows),
 'maxWithinPairYieldDifferencePercent':max(abs(p['yieldDifferencePercent']) for p in pairs),
 'fullCampaignLowRateYieldDriftPercent':(max(c['gainPerSerialRequest'] for c in cals.values())/min(c['gainPerSerialRequest'] for c in cals.values())-1)*100,
 'noRuntimeErrors':True,'bothFastTrainingStoppedAtEnd':True,'r7RepSpeedBoostPercent':sum(p['perks'].get('repTimeBoostPercent',0) for p in d['initialPets'])},
 'numericHandling':'Strength counters restored to Luau binary64 before subtraction; raw game JSON bytes retained unchanged',
 'limitations':['single Mac Opiumware account/server session; Android Delta not tested','five repeated trials; t confidence intervals depend on independence and approximate distribution assumptions',
 '30-second runs and last15 windows describe short tests, not 90-second or indefinite sustained rates','Data Ping is the game statistic, not an individual request acknowledgement',
 'pet strength perks grow automatically; each trial is separately calibrated; normalized results are conditional on low-rate yield scaling remaining applicable',
 'actual wall seconds used; tail drain is recorded separately; calibration and rest are excluded from training rates']}
(out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'runId':result['runId'],'comparison':comparison,'quality':result['quality'],'groupMeans':{m:{k:round(summary[m][k]['mean'],3) for k in metrics} for m in summary}},ensure_ascii=False,indent=2))
